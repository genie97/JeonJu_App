package org.androidtown.jeonjuro2018;

public class scheduleInfo {
    String title;

    public scheduleInfo(String title) {
        this.title=title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}
